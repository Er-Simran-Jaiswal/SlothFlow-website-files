import { pipeline, env } from 'https://cdn.jsdelivr.net/npm/@xenova/transformers@2.17.2';

// Model inference is performed in the browser. No app backend receives the text.
env.allowLocalModels = false;
env.useBrowserCache = true;

const input = document.querySelector('#brainDump');
const planBtn = document.querySelector('#planBtn');
const statusBox = document.querySelector('#status');
const results = document.querySelector('#results');
const output = document.querySelector('#planOutput');
const copyBtn = document.querySelector('#copyBtn');
let generatorPromise;
let currentPlan = [];

function setStatus(title, message, icon='☁') {
  statusBox.querySelector('.status-icon').textContent = icon;
  statusBox.querySelector('strong').textContent = title;
  statusBox.querySelector('p').textContent = message;
}
function fallbackPlan(text) {
  // Helpful fallback if model download is unavailable; this does not pretend to be AI.
  const lines = text.split(/\n|,|;|(?<=\.)\s+/).map(s=>s.trim()).filter(Boolean);
  return lines.slice(0,6).map((line,i)=>({
    title: line.replace(/^[-•\d.)\s]+/, '').replace(/[.!?]+$/,''),
    time: i===0?'START HERE':i<3?'NEXT':'WHEN YOU HAVE ENERGY'
  })).filter(x=>x.title);
}
async function getGenerator() {
  if (!generatorPromise) {
    generatorPromise = pipeline('text2text-generation', 'Xenova/flan-t5-small', {
      progress_callback: p => {
        if (p.status === 'progress' && p.total) {
          const pct = Math.round(p.loaded / p.total * 100);
          setStatus('Getting your local AI ready', `Downloading model files: ${pct}%. This is usually needed only once.`, '🌱');
        } else if (p.status === 'initiate') {
          setStatus('Waking up the sloth', 'Loading the open-weight model into your browser…', '🌱');
        }
      }
    });
  }
  return generatorPromise;
}
function parseTasks(text) {
  return text.split(/\n+/).map(s=>s.replace(/^\s*(?:[-*•]|\d+[.)])\s*/, '').trim())
    .filter(s=>s.length>2).slice(0,6).map((title,i)=>({title, time:i===0?'START HERE':i<3?'NEXT':'WHEN YOU HAVE ENERGY'}));
}
function renderPlan(tasks) {
  currentPlan = tasks;
  output.replaceChildren();
  tasks.forEach((task,i)=>{
    const row=document.createElement('div'); row.className='task';
    const check=document.createElement('input'); check.type='checkbox'; check.id=`task-${i}`;
    const label=document.createElement('label'); label.htmlFor=check.id;
    const small=document.createElement('small'); small.textContent=task.time || 'ONE SMALL STEP';
    const title=document.createElement('span'); title.textContent=task.title;
    label.append(small,title); row.append(check,label); output.append(row);
  });
  results.classList.remove('hidden');
}
planBtn.addEventListener('click', async()=>{
  const text=input.value.trim();
  if(!text){setStatus('Give your thoughts a place to land','Type a few tasks or a messy brain dump first.','✍️');input.focus();return;}
  planBtn.disabled=true;planBtn.textContent='Making space…';
  results.classList.add('hidden');
  try{
    setStatus('Waking up the sloth','The first run downloads the open-weight model. After that, it can use your browser cache.','🌱');
    const generator=await getGenerator();
    const prompt=`Turn this messy to-do list into a calm, simple action plan. Keep the original tasks, use short clear lines, combine duplicates, put the easiest useful first step first, and split big tasks into tiny actions. Output only 3 to 6 numbered action lines. Do not add tasks that are not implied by the input.\nTo-do list: ${text}`;
    const result=await generator(prompt,{max_new_tokens:180, do_sample:false});
    const generated=String(result?.[0]?.generated_text||'');
    const tasks=parseTasks(generated);
    if(!tasks.length) throw new Error('The model did not return a usable plan.');
    renderPlan(tasks);
    setStatus('Your plan is ready','Check off one tiny step. You do not have to do everything today.','🌿');
  }catch(err){
    console.warn(err);
    const tasks=fallbackPlan(text);
    renderPlan(tasks);
    setStatus('Simple plan ready','The local AI could not load right now, so we made a basic checklist from your notes. Check your internet connection and reload to try the model again.','🧩');
  }finally{
    planBtn.disabled=false;planBtn.innerHTML='<span>✦</span> Make it manageable';
  }
});
copyBtn.addEventListener('click',async()=>{
  const text=currentPlan.map((t,i)=>`${i+1}. ${t.title}`).join('\n');
  try{await navigator.clipboard.writeText(text);copyBtn.textContent='Copied!';setTimeout(()=>copyBtn.textContent='Copy plan',1400);}
  catch{setStatus('Select and copy your plan','Clipboard access was blocked by your browser.','📋');}
});
