# SlothFlow 🦥

**Less overwhelm. One small step.** SlothFlow turns a messy brain dump into a small action plan using an open-weight language model directly in the browser.

## Why open innovation matters

- **Privacy by design:** the text you enter is processed in the browser; there is no SlothFlow backend receiving it.
- **Open weights:** it uses `Xenova/flan-t5-small`, a browser-compatible conversion of FLAN-T5 Small, through Transformers.js.
- **Low running cost:** there is no paid inference API or server to maintain.
- **Flexible:** the model can be replaced or the prompt changed without being locked to one hosted AI provider.

The model files are fetched from the public model CDN on first use, so the first run needs internet. Browser caching may let it load again later without downloading every file, but fully offline behavior depends on browser cache and model availability. This project does not promise guaranteed offline use on every device.

## Run it locally

Because this uses JavaScript modules, open it through a local web server rather than double-clicking `index.html`.

If you have Python 3 installed:

```bash
cd slothflow
python3 -m http.server 8000
```

Then open <http://localhost:8000>.

## Publish it with GitHub Pages

1. Create a public GitHub repository named `slothflow`.
2. Upload `index.html`, `style.css`, `app.js`, and `README.md` to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Choose branch `main` and folder `/(root)`, then save.
6. Wait for GitHub Pages to publish. Your website will be at `https://YOUR-USERNAME.github.io/slothflow/`.

Replace `YOUR-USERNAME` with your GitHub username. GitHub creates the real link only after you publish the repository.

## Tech

- HTML, CSS, JavaScript
- [Transformers.js](https://github.com/xenova/transformers.js)
- [FLAN-T5 Small model](https://huggingface.co/Xenova/flan-t5-small)
- MIT License

## Notes

The first model download can take a little time. If model loading fails, SlothFlow falls back to a basic checklist so the page remains usable. The fallback is not AI-generated.
